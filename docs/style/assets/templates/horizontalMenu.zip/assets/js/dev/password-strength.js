(function($) {
	var methods = {
		init : function(element, options) {
			var self = $(element);
			self.options = $.extend({}, $.fn.passwordStrength.setting, options);
			self.on("keyup", function(e) {
				var obj = {
					ele : $(this),
					value : $(this).val(),
					options : self.options
				};
				methods.checkLength(obj);
			}).on("blur", function(e) {
				var target = $(this);
			});
			this.self = self;
		},
		caseFinder : function(obj) {
			var val = obj.value, value_split = val.split(''), upperTextArr = upperTextArr || [], lowerTextArr = lowerTextArr || [], numericArr = numericArr || [], specialArr = specialArr || [];
			for (var i in value_split) {
				if (value_split[i].match(/[A-Z]/)) {
					upperTextArr.push(value_split[i]);
				} else if (value_split[i].match(/[a-z]/)) {
					lowerTextArr.push(value_split[i]);
				} else if (value_split[i].match(/[0-9]/)) {
					numericArr.push(value_split[i]);
				} else {
					specialArr.push(value_split[i]);
				}
			}
			var upper_score = (upperTextArr.length > 1) ? 25 : ((upperTextArr.length == 1) ? 12.5 : 0);
			var lower_score = (lowerTextArr.length > 1) ? 25 : ((lowerTextArr.length == 1) ? 12.5 : 0);
			var num_score = (numericArr.length > 1) ? 25 : ((numericArr.length == 1) ? 12.5 : 0);
			var spec_score = (specialArr.length > 1) ? 25 : ((specialArr.length == 1) ? 12.5 : 0);
			obj.score = upper_score + lower_score + num_score + spec_score;
			methods.progressBarShow(obj);
			return this;
		},
		progressBarShow : function(obj) {
			var ele = $(obj.ele), nextElem = $(ele).next(), parent = nextElem.parent();
			if (nextElem.length === 0) {
				$(obj.options.progressTemplate).insertAfter(ele).parent().addClass('pull-relative');
				methods.progressBarWidth(obj);
			}
			if (nextElem.length > 0) {
				methods.progressBarWidth(obj);
			}
			return this;
		},
		progressBarWidth : function(obj) {
			var ele = $(obj.ele), nextElem = $(ele).next(), barClass = barClass || [];
			var barType = {
				w : ['Weak','progress-bar-danger'],
				m : ['Medium','progress-bar-warning'],
				s : ['Strong', 'progress-bar-success']
			};
			barClass = (obj.score <= 40) ? barType.w : ((obj.score > 40 && obj.score <= 83) ? barType.m : barType.s);
			$('.progress-bar', nextElem).width(obj.score + '%').attr('class','progress-bar '+barClass[1]).text(barClass[0]);
		},
		progressBarHide : function(obj) {
			var ele = $(obj.ele), nextElem = $(ele).next();
			if (nextElem.length > 0) {
				nextElem.remove();
			}
		},
		checkLength : function(obj) {
			var elem = $(obj.ele), length = elem.val().length;
			(length > 0) ? methods.caseFinder(obj) : methods.progressBarHide(obj);
			return this;
		}
	};
	$.fn.passwordStrength = function(options, ele) {
		return this.each(function() {
			methods.init($(this), options || {});
		});
	};
	$.fn.passwordStrength.setting = {
		minChar : 8,
		errorMessages : {
			password_length_err : "The Password is too short",
			same_as_username : "Your password cannot be the same as your username"
		},
		usernameField : "#username",
		progressTemplate : '<div class="progress pwd_strength"><div style="width: 0%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="0" role="progressbar" class="progress-bar"></div></div>'
	};
})(jQuery);
